# 🔒 Key Inventory — Delta Report
**Date:** 2026-08-01 06:00 UTC — **Run #15+ of this cron**
**Status:** ✅ No changes since baseline (04:36 UTC)

## Delta Summary

| Dimension | Baseline (04:36 UTC) | Now (06:00 UTC) | Change |
|-----------|--------------------:|-----------------:|:------:|
| Env vars matching sensitive patterns | 2 | 2 | ✅ None |
| Credential files on disk | 6 files | 6 files | ✅ None |
| .env backups | 7 | 7 | ✅ None |
| Sessions with credential exposure | 7 tracked | 7 tracked | ✅ None |
| Config export | Exported | Re-exported | ✅ Done |
| OpenRouter endpoint | 401 | 401 | ✅ Stable |
| Google OAuth endpoint | 404 (GET) | 404 (GET) | ✅ Stable |

## Current Snapshot

**Env vars:** `CUSTOM_API_KEY` (56 chars, Hermes-masked), `HERMES_REDACT_SECRETS` (true)

**Credential files** (all Jun 15 – Jul 2 timestamps, unchanged):
- `/opt/data/.env` — 163B, Jul 2 12:01
- `/opt/data/.or_key` — 73B, Jun 15 01:59
- `/opt/data/.or_key_b64` — 100B, Jun 15 02:00
- `/opt/data/google_client_secret.json` — 410B, Jun 15 00:14
- `/opt/data/google_token.json` — 1197B, Jun 15 02:58
- `/opt/data/auth.json` — 1725B, Jul 2 12:02

**Outstanding recommendations (unaddressed since baseline):**
- 🔴 Rotate DEEPSEEK_API_KEY (plaintext in `.env`)
- 🔴 Rotate OpenRouter key `sk-or-...d8ab` (2 files: `.or_key` + `.or_key_b64`)
- 🔴 Revoke Google refresh_token (full Workspace access — Gmail/Drive/Sheets/Calendar/Tasks)
- 🟡 Revoke OAuth client (client_secret `GOCSPX-...` leaked in Telegram Jun 12)
- 🟡 Delete 7 stale `.env.bak-*` files
- 🟡 Fix cron `Log uso 18:00 BRT` — Sheets API timeout

**Full baseline:** `/opt/data/skills/security/credential-audit/references/audit-2026-08-01.md`