# FTS5 Query Quirks for session_search

## Silent Failures with OR + Special Characters

SQLite FTS5 tokenization can silently return 0 results on queries containing tokens with:
- **Hyphens** (`sk-or-`, `non-blocking`)
- **Dots** (`credentials.json`, `file.txt`)
- **Slashes** (`api/v1`, `path/to`)
- **Underscores combined with other special chars**

### Observed Pattern

This query returned **0 results** despite individual terms matching:
```
session_search(query="api_key OR token OR credential OR sk-or- OR client_secret")
```

But these **all returned results**:
```
session_search(query="api_key", ...)               → 9 sessions
session_search(query="token OR credential", ...)   → 7 sessions
session_search(query="sk-or-", ...)                → multiple hits
session_search(query="credentials.json", ...)      → multiple hits
```

### Workaround

- Keep OR queries to **2-3 terms max**
- Avoid combining terms with special chars (hyphens, dots, slashes) in the same OR query
- Run separate `session_search()` calls per pattern group
- Deduplicate results manually (use `session_id` field)
- Prefer simpler patterns: `api_key OR token OR credential` (no special chars) works reliably