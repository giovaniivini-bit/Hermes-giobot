# Google Sheets API Timeout Forensics

## Symptom

Cron job exits with code 1 and this traceback:

```
TimeoutError: The read operation timed out

During handling of the above exception, another exception occurred:

  File ".../googleapiclient/http.py", line ..., in execute
    resp, content = _retry_request(...)
  File ".../googleapiclient/http.py", line ..., in _retry_request
    raise TimeoutError(...)
```

Full call chain seen in practice:
```
log_usage.py:main()
  → log_usage.py:sheets_read_last(svc)
    → service.spreadsheets().values().get(...).execute()
      → googleapiclient/http.py:_retry_request()
        → googleapiclient/http.py:execute()
          → ssl.py:recv_into() → ssl.py:read()
            → socket.py:readinto()
              → TimeoutError: The read operation timed out
```

## Diagnosis

Check whether the Sheets API endpoint itself is reachable:

```bash
curl -s -o /dev/null -w 'HTTP %{http_code} (%{time_total}s)' --max-time 5 https://sheets.googleapis.com/v4/spreadsheets
```

- **HTTP 400** → Endpoint is live. The 400 means "bad request without valid auth" — exactly what's expected when hitting it with no Bearer token. The timeout was a **transient network/SSL hiccup**, not a dead endpoint or bad credential.
- **Connection timeout** → Endpoint unreachable. Check firewall, DNS, or Google Workspace outage.

## Root Cause

This is almost always a transient network issue at the SSL read layer. The TLS handshake succeeded (the connection was established) but the response data stream stalled. Common triggers:

- Brief Google API latency spike
- Oracle VM egress throttling
- Intermediate proxy/load-balancer timeout
- Coincident high load on the Sheets API

## Fix

**Add retry logic** to the sheets API call in `log_usage.py`. Google's own Python client supports retries natively:

```python
from googleapiclient.http import build_http
from google.auth.transport.requests import AuthorizedSession
import time

def sheets_read_last(svc, max_retries=3, backoff=2):
    for attempt in range(max_retries):
        try:
            result = (
                svc.spreadsheets()
                .values()
                .get(spreadsheet_id=SPREADSHEET_ID, range="B:B")
                .execute()
            )
            values = result.get("values", [])
            return float(values[-1][0]) if values else 0.0
        except TimeoutError as e:
            if attempt == max_retries - 1:
                raise
            time.sleep(backoff ** attempt)
```

Alternatively, use google-api-python-client's built-in retry:

```python
from googleapiclient.http import set_user_agent
# The client already retries on 5xx and timeouts by default
# if http= parameter is set up with a retry-capable transport
```

## Verification After Fix

1. Test the script directly: `cd /opt/data && python3 scripts/log_usage.py`
2. Check the cron status: `/opt/hermes/.venv/bin/hermes cron list`
3. Confirm the endpoint is alive: `curl -s -o /dev/null -w '%{http_code}' https://sheets.googleapis.com/v4/spreadsheets`

## When to Escalate (not a transient issue)

The timeout is NOT transient if ALL of these are true:
- Sheets endpoint returns **connection refused** or **DNS resolution failure** (not 400)
- The Google token is expired AND the refresh token fails (check `google_token.json` expiry)
- Multiple crons across different time slots all fail with the same timeout
- Google Workspace status dashboard shows an outage