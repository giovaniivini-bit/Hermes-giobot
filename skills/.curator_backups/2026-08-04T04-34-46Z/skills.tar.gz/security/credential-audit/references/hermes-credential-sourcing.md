# Hermes Credential Sourcing Architecture

Understanding where API keys live in a Hermes environment and why they don't always appear where you expect.

## Three Credential Layers

| Layer | Path | Managed By | Exported to Env? | Notes |
|-------|------|------------|:----------------:|-------|
| **Process Environment** | Injected by Docker, shell profile, container orchestrator | Platform/infra | Yes (visible via `env`) | Redacted by `HERMES_REDACT_SECRETS` if set |
| **`.env` file** | `/opt/data/.env` | Hermes provider config (`env_file:`) | No (not auto-exported) | Only keys referenced in `config.yaml` are loaded |
| **`auth.json` credential pool** | `/opt/data/auth.json` | `hermes auth` CLI | No (read internally by Hermes) | Keys available to agent via credential store lookups |

## Why "rogue keys" exist

A key may appear in `env` output (or be derivable from length/prefix via Python reading) without being in `.env` or `auth.json`. Sources:

1. **Docker `-e` / `--env-file`** — the Hermes container receives env vars from the host
2. **Shell profile injection** — `~/.bashrc`, `~/.profile`, or `init.d` scripts set vars at login
3. **Platform/s6 injectors** — the `_HERMES_GATEWAY` env and similar infra vars
4. **Secrets manager integration** — external secret stores (Vault, Doppler, 1Password) inject into the process

## Audit Implications

- **`.env` scanning alone misses rogue keys.** Always cross-reference process env vs `.env` keys vs `auth.json` labels.
- **`auth.json` is the authoritative store** for Hermes-managed credentials. Keys there are rotated via `hermes auth set`.
- **Rogue keys can't be rotated through Hermes** — the operator must update the external injection source.
- **The agent's process environment differs from the cron's.** When running as a cron job, only env vars the Hermes cron runner injects are available — not all shell profile vars.