# Credential Security Audit — Delta Report

**Generated:** 2026-08-07 06:02 UTC | **Cron:** `key_inventory` (daily)
**Model:** deepseek/deepseek-v4-flash | **Provider:** openrouter

---

**No changes since baseline 2026-08-04. All metrics stable for 6 consecutive daily runs.**

## State Summary (unchanged)

| Dimension | Status | Detail |
|-----------|:------:|--------|
| **Env vars** | No change | 3 active: `CUSTOM_API_KEY` (rogue, Groq `gsk_kCIQ...`), `DEEPSEEK_API_KEY` (managed), `HERMES_REDACT_SECRETS` |
| **Credential files** | No change | 8 active + 7 clean `.env.bak-*` — all SHA256/sizes unchanged |
| **Rogue keys (env-only)** | 1 | `CUSTOM_API_KEY` (`gsk_kCIQ...`, 56 chars) — not in `.env` or `auth.json` |
| **Session exposures** | No new | 8 tracked non-cron sessions — no new exposures since Jul 10 |
| **Cron health** | 3/3 OK | 0% error rate — self-resolved Aug 01, stayed OK for 6 runs |
| **Endpoints** | 5/5 live | OpenRouter 401, OAuth 404, Sheets 400, OpenAI 401, DeepSeek 401 |
| **Schedule** | Throttled | `0 6 * * *` (daily) — implemented Aug 01, no further action needed |

## Audit Verification (this run)

- **Env scan:** Redaction active (`HERMES_REDACT_SECRETS`). `.env` keys: `DEEPSEEK_API_KEY` (len=35), `DEEPSEEK_BASE_URL` (len=25, non-secret), `TELEGRAM_HOME_CHANNEL` (len=10), `TELEGRAM_HOME_CHANNEL_THREAD_ID` (empty). Process-env rogue cross-reference `CUSTOM_API_KEY` only.
- **auth.json store:** openrouter OPENROUTER_API_KEY, openai-api OPENAI_API_KEY, deepseek DEEPSEEK_API_KEY. 3 credentials total. File unchanged (1725B).
- **Rogue key check:** `CUSTOM_API_KEY` (`gsk_kCIQ...`, 56 chars) present in process env, NOT in `.env` or `auth.json` — rogue (carryover, unchanged since Aug 01).
- **Base64 duplicate check:** `.or_key` (73B) == decoded `.or_key_b64` (100B) — MATCH. `~/.hermes/scripts/.or_key_b64` decoded == original — MATCH.
- **Credential file integrity:**
  - `.env` (163B, non-sensitive channel config only)
  - `.or_key` (73B, `sk-or-v1-d3e...`)
  - `.or_key_b64` (100B)
  - `google_client_secret.json` (424B, VALID, `GOCSPX-a...` client_secret, len=35)
  - `google_token.json` (1135B, VALID — refresh_token present, 9 Workspace scopes)
  - `auth.json` (1302B, VALID)
  - `skills/productivity/google-workspace/credentials.json` (424B, VALID — same client_secret)
  - `.hermes/google-workspace/tool_configs/credentials.json` (345B, INVALID JSON — stub wrapped in markdown fences)

- **`.env.bak-*` files:** All 7 verified — only `TELEGRAM_HOME_CHANNEL` and `TELEGRAM_HOME_CHANNEL_THREAD_ID`. No keys. Not a risk.
- **Session search:** `api_key` query: all cron-source matches (audit discovering itself). `token OR secret`: all cron-source matches. `client_secret OR sk-or-`: 0 results (FTS5 special-char limitation). Zero new non-cron exposures.
- **Endpoints:** All 5 live — OpenRouter 401, Google OAuth 404 (GET), Sheets 400, OpenAI 401, DeepSeek 401.

## Outstanding Issues (all carryover, unchanged)

| Prio | Issue | First Flagged |
|:----:|-------|:------------:|
| RED | `CUSTOM_API_KEY` — rogue Groq key in process env, not managed by Hermes | Aug 01 |
| RED | `DEEPSEEK_API_KEY` in plaintext `.env` | Aug 01 |
| RED | OpenRouter key in 2 plaintext files + 1 duplicate (`~/.hermes/scripts/.or_key_b64`) | Aug 01 |
| RED | Google OAuth refresh_token with full Workspace access (Gmail/Drive/Sheets/Calendar/Tasks) | Aug 01 |
| YELLOW | OAuth `client_secret` (`GOCSPX-a...`) leaked in Telegram (Jun 12) | Aug 01 |
| GREEN | Invalid/stub `credentials.json` in `.hermes/google-workspace/tool_configs/` (wrapped in markdown fences) | Aug 01 |

## No-Changes Trend

| Day | Run Count | Consecutive Identical Reports |
|:---:|:---------:|:----------------------------:|
| Aug 04 | 1 | Baseline |
| Aug 05 | 1 | 1st |
| Aug 06 | 1 | 2nd |
| Aug 07 | 1 | **3rd consecutive identical** |

## Statistics

| Metric | Count |
|:-------|:-----:|
| Active API keys | 3 (DEEPSEEK, OpenRouter, Groq rogue) |
| Credential files (RED) | 8 |
| Duplicate credential copies | 3 (`.or_key_b64` x2, `credentials.json` x2) |
| Stale `.env.bak-*` (GREEN) | 7 (non-sensitive) |
| Non-cron sessions with exposures | 0 (all cron self-detection) |
| Active cron jobs | 3 (all OK) |
| Endpoints verified | 5/5 live |
| Error rate (last 6 runs) | 0% |