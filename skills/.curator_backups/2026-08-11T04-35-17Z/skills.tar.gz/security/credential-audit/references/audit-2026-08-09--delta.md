# Credential Security Audit — Delta Report

**Generated:** 2026-08-09 06:00 UTC | **Cron:** `key_inventory` (`0 6 * * *`, daily)
**Model:** qwen/qwen3.7-flash | **Provider:** openrouter

---

## No changes since baseline 2026-08-08. All metrics stable for 2 consecutive daily runs.

### State Summary (unchanged)

| Dimension | Status | Detail |
|-----------|:------:|--------|
| **Env vars** | No change | `CUSTOM_API_KEY` (rogue Groq, 56 chars), `DEEPSEEK_API_KEY` (managed, .env only), `HERMES_REDACT_SECRETS` (active) |
| **Credential files** | No change | 8 active + 7 clean `.env.bak-*` — SHA256s and sizes identical to baseline |
| **Rogue keys (env-only)** | 1 | `CUSTOM_API_KEY` — Groq key (`gsk_kCIQ...`), process env only, not in `.env` or `auth.json` |
| **Session exposures** | No new | All FTS5 matches are cron self-detection; zero non-cron source exposures detected |
| **Cron health** | 3/3 OK | 0% error rate across all jobs |
| **Endpoints** | 5/5 live | OpenRouter 401, OAuth 404, Sheets 400, OpenAI 401, DeepSeek 401 |
| **Schedule** | Throttled | `0 6 * * *` (daily since Aug 01) |

### Audit Verification (this run)

- **Env scan:** Redaction active. `.env` keys: DEEPSEEK_API_KEY (len=35, prefix `sk-6`), DEEPSEEK_BASE_URL (len=25), TELEGRAM_HOME_CHANNEL (len=10), TELEGRAM_HOME_CHANNEL_THREAD_ID (empty).
- **Process-env rogue cross-reference:** Only `CUSTOM_API_KEY` (`gsk_kCIQ...`, 56 chars) — unchanged.
- **auth.json store:** 3 managed credentials: openrouter OPENROUTER_API_KEY, openai-api OPENAI_API_KEY, deepseek DEEPSEEK_API_KEY. File unchanged (1725B).
- **Base64 duplicate check:** `.or_key` (73B) == decoded `.or_key_b64` (100B) — MATCH. `~/.hermes/scripts/.or_key_b64` decoded == original — MATCH.
- **Google token:** refresh_token present (103 chars, `1//0hclisbFq...`), no access_token (stale), expiry present. Full Workspace scopes retained.
- **File system integrity:** No files newer than baseline timestamp. All credential files intact.

### Outstanding Issues (all carryover, unchanged)

| Prio | Issue | First Flagged |
|:----:|-------|:------------:|
| RED | Rogue `CUSTOM_API_KEY` (Groq `gsk_kCIQ...`) in process env, unmanaged by Hermes | Aug 01 |
| RED | `DEEPSEEK_API_KEY` in plaintext `.env` (should use credential store) | Aug 01 |
| RED | OpenRouter key in 3 locations (`.or_key`, `.or_key_b64`, `~/.hermes/scripts/.or_key_b64`) | Aug 01 |
| RED | Google OAuth refresh_token with full Workspace access (Gmail/Drive/Sheets/Calendar/Tasks/Contacts) | Aug 01 |
| YELLOW | OAuth `client_secret` leaked in Telegram chat (Jun 12) — GOCSPX-... | Aug 01 |
| GREEN | Stub/misconfigured `credentials.json` in `.hermes/google-workspace/tool_configs/` | Aug 01 |
| GREEN | 7 stale `.env.bak-*` files (non-sensitive, but cleanup recommended) | Aug 01 |

### Consecutive Identical Runs

| Day | Run | Notes |
|:---:|-----|-------|
| Aug 08 | Baseline | Full snapshot |
| Aug 09 | 2nd | No changes |

### Statistics

| Metric | Count |
|:-------|:-----:|
| Active API keys | 3 (DEEPSEEK, OpenRouter, Groq rogue) |
| Credential files (RED risk) | 8 |
| Duplicate credential copies | 3 |
| Stale `.env.bak-*` (GREEN) | 7 |
| Non-cron session exposures | 0 |
| Active cron jobs | 3 (all OK) |
| Endpoints verified | 5/5 live |
| Error rate | 0% |
