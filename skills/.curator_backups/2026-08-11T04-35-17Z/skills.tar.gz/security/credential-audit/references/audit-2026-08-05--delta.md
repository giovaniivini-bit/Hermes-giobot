# 🔒 Credential Security Audit — Delta Report

**Generated:** 2026-08-05 06:00 UTC | **Cron:** `key_inventory` (daily)
**Model:** deepseek/deepseek-v4-flash | **Provider:** openrouter

---

**No changes since baseline 2026-08-04. All metrics stable for 4 consecutive daily runs.**

## 🟢 State Summary (unchanged)

| Dimension | Status | Detail |
|-----------|:------:|--------|
| **Env vars** | ✅ No change | 3 active: `CUSTOM_API_KEY` (rogue, Groq `gsk_...`), `DEEPSEEK_API_KEY` (managed), `HERMES_REDACT_SECRETS` |
| **Credential files** | ✅ No change | 8 active + 7 clean `.env.bak-*` — SHA256 unchanged since Jul 02 |
| **Rogue keys (env-only)** | ✅ 1 | `CUSTOM_API_KEY` (`gsk_kCIQ...`, 56 chars) — not in `.env` or `auth.json` |
| **Session exposures** | ✅ No new | 7 tracked non-cron sessions — no new exposures since Jul 10 |
| **Cron health** | ✅ 3/3 OK | 0% error rate — Sheet timeout self-resolved Aug 01, stayed OK for 4 runs |
| **Endpoints** | ✅ 5/5 live | OpenRouter 401, OAuth 404, Sheets 400, OpenAI 401, DeepSeek 401 |
| **Schedule** | ✅ Throttled | `0 6 * * *` (daily) — implemented Aug 01, no further action needed |

## 🔍 Audit Verification (this run)

- **Env scan:** Redaction active (`HERMES_REDACT_SECRETS`). `.env` keys: `DEEPSEEK_API_KEY`, `DEEPSEEK_BASE_URL`, `TELEGRAM_HOME_CHANNEL`, `TELEGRAM_HOME_CHANNEL_THREAD_ID`. Process-env rogue cross-reference → `CUSTOM_API_KEY` only.
- **auth.json store:** openrouter → OPENROUTER_API_KEY, openai-api → OPENAI_API_KEY, deepseek → DEEPSEEK_API_KEY.
- **Rogue key check:** `CUSTOM_API_KEY` present in process env, NOT in `.env` or `auth.json` → ⚠️ rogue (carryover issue).
- **Base64 duplicate check:** `.or_key` (73B, `sk-or-v1-d3e...`) == decoded `.or_key_b64` (100B) → **MATCH**. Duplicate `home/.hermes/scripts/.or_key_b64` == original → **MATCH**.
- **Credential file integrity:** `.env` (163B), `.or_key` (73B), `.or_key_b64` (100B), `google_token.json` (1197B, refresh_token present, full Workspace scopes), `google_client_secret.json` (410B, client_secret `GOCSPX...`), `auth.json` (1725B) — all valid. ⚠️ `/opt/data/.hermes/google-workspace/tool_configs/credentials.json` is **INVALID JSON** (empty/stub) — carries the same Google client_secret risk classification as before but is a stub, not a live config.
- **Session search:** FTS5 queries (`api_key`, `token OR secret`, `client_secret OR sk-or-`) returned only `cron`-source sessions (the audit discovering itself). **Zero new non-cron exposures.**
- **Endpoints:** All 5 live — OpenRouter 401, Google OAuth 404 (GET), Sheets 400, OpenAI 401, DeepSeek 401.

## 🔴 Outstanding Issues (all carryover, unchanged)

| Prio | Issue | First Flagged |
|:----:|-------|:------------:|
| 🔴 | `CUSTOM_API_KEY` — rogue Groq key in process env, not managed by Hermes | Aug 01 |
| 🔴 | `DEEPSEEK_API_KEY` in plaintext `.env` | Aug 01 |
| 🔴 | OpenRouter key in 2 plaintext files + 1 duplicate (`~/.hermes/scripts/.or_key_b64`) | Aug 01 |
| 🔴 | Google OAuth refresh_token with full Workspace access (Gmail/Drive/Sheets/Calendar/Tasks) | Aug 01 |
| 🟡 | OAuth `client_secret` (`GOCSPX-...`) leaked in Telegram (Jun 12) | Aug 01 |
| 🟡 | 7 stale `.env.bak-*` files on disk | Aug 01 |
| 🟢 | Invalid/stub `credentials.json` in `.hermes/google-workspace/tool_configs/` | Aug 01 |

## 📊 Statistics

| Metric | Count |
|:-------|:-----:|
| Active API keys | 3 (DEEPSEEK, OpenRouter, Groq rogue) |
| Credential files (🔴) | 8 (.env, .or_key, .or_key_b64, google_client_secret, google_token, auth.json, 2× credentials.json dupes) |
| Duplicate credential copies | 3 (`.or_key_b64` ×2, `credentials.json` ×2) |
| Clean backups | 7 (`.env.bak-*`, channel config only) |
| Rogue keys (env-only) | 1 (`CUSTOM_API_KEY`) |
| Exposed sessions | 7 (non-cron, Jun 12 – Jul 10) |
| Cron jobs | 3 — **0% error rate** (all OK for 4+ runs) |
| Endpoints verified | 5 — all live |

**Convenience copy:** `/opt/data/security_audit_report_20260805_060000.md`