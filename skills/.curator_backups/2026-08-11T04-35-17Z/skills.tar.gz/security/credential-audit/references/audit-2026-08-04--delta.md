# 🔒 Credential Security Audit — Delta Report

**Generated:** 2026-08-04 06:33 UTC | **Cron:** `key_inventory` (daily)
**Model:** deepseek/deepseek-v4-flash | **Config exported:** ✅

---

**No changes since baseline 2026-08-03. All metrics stable for 3 consecutive daily runs.**

## 🟢 State Summary (unchanged)

| Dimension | Status | Detail |
|-----------|:------:|--------|
| **Env vars** | ✅ No change | 3 active: `CUSTOM_API_KEY` (rogue, Groq `gsk_...`), `DEEPSEEK_API_KEY` (managed), `HERMES_REDACT_SECRETS` |
| **Credential files** | ✅ No change | 8 active + 7 clean `.env.bak-*` — all SHA256 unchanged since Jul 02 |
| **Rogue keys (env-only)** | ✅ 1 | `CUSTOM_API_KEY` (`gsk_kCIQ...`, 56 chars) — not in `.env` or `auth.json` |
| **Session exposures** | ✅ No new | 7 tracked non-cron sessions — no new exposures since Jul 10 |
| **Cron health** | ✅ 3/3 OK | 0% error rate — Sheet timeout self-resolved on Aug 01, stayed OK for 3 runs |
| **Endpoints** | ✅ 5/5 live | OpenRouter 401, OAuth 404, Sheets 400, OpenAI 401, DeepSeek 401 |
| **Schedule** | ✅ Throttled | `0 6 * * *` (daily) — implemented Aug 01, no further action needed |

## 🔴 Outstanding Issues (all carryover, unchanged)

| Prio | Issue | First Flagged |
|:----:|-------|:------------:|
| 🔴 | `CUSTOM_API_KEY` — rogue Groq key in process env, not managed by Hermes | Aug 01 |
| 🔴 | `DEEPSEEK_API_KEY` in plaintext `.env` | Aug 01 |
| 🔴 | OpenRouter key in 2 plaintext files + 1 duplicate (`~/.hermes/scripts/.or_key_b64`) | Aug 01 |
| 🔴 | Google OAuth refresh_token with full Workspace access (Gmail/Drive/Sheets/Calendar/Tasks) | Aug 01 |
| 🟡 | OAuth `client_secret` (`GOCSPX-...`) leaked in Telegram (Jun 12) | Aug 01 |
| 🟡 | 7 stale `.env.bak-*` files on disk | Aug 01 |
| 🟢 | Empty KEY stubs in `.env` (OPENAI, ANTHROPIC, OPENROUTER) | Aug 01 |

## 📊 Statistics

| Metric | Count |
|:-------|:-----:|
| Active API keys | 3 (DEEPSEEK, OpenRouter, Groq rogue) |
| Credential files (🔴) | 8 (.env, .or_key, .or_key_b64, google_client_secret, google_token, auth.json, 2× credentials.json dupes) |
| Duplicate credential copies | 3 (`.or_key_b64` ×2, `credentials.json` ×2) |
| Clean backups | 7 (`.env.bak-*`, channel config only) |
| Rogue keys (env-only) | 1 (`CUSTOM_API_KEY`) |
| Exposed sessions | 7 (non-cron, Jun 12 – Jul 10) |
| Cron jobs | 3 — **0% error rate** (all OK for 3+ runs) |
| Endpoints verified | 5 — all live |

**Convenience copy:** `/opt/data/security_audit_report_20260804_063300.md`