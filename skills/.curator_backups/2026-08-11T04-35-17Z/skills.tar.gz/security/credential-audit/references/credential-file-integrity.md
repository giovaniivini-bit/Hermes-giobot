# Credential File Integrity Validation

Not all `credentials.json` files on disk contain valid credentials. Files that exist but fail to parse are a different risk class — they may be stale tool_config stubs, partial writes, or misconfigured paths.

## Detecting Corrupt/Empty Credential Files

After Phase 3's `find` step lists credential files, run a quick integrity pass:

```bash
echo "=== JSON integrity check ==="
for f in $(find /opt/data -maxdepth 5 -name "credentials.json" \
           -not -path "*/venv/*" -not -path "*/.cache/*" 2>/dev/null); do
  python3 -c "
import json, sys
try:
    with open('$f') as fp:
        data = json.load(fp)
    # Check for expected OAuth key structure
    installed = data.get('installed', data)
    has_client_secret = bool(installed.get('client_secret'))
    print(f'  OK $f (client_secret: {has_client_secret})')
except json.JSONDecodeError as e:
    print(f'  ⚠️ CORRUPT $f — {e}')
except Exception as e:
    print(f'  ⚠️ ERROR $f — {e}')
"
done
```

## Interpretation

| State | Meaning | Risk |
|-------|---------|:----:|
| **Valid JSON, has `client_secret`** | Real OAuth credential | 🔴 |
| **Valid JSON, no `client_secret`** | Stub/template — may have `client_id` only or be a skeleton config | 🟡 |
| **Zero-byte file** | Stale artifact from failed tool_config write | 🟢 (flag as cleanup) |
| **Non-zero but corrupt JSON** | Partial write, wrong file format, or tool_config pointing at wrong path | 🟡 (investigate) |
| **File not found** | Referenced in tool_config but missing — broken setup | 🟡 |

## Common Sources

- **`~/.hermes/<service>/tool_configs/credentials.json`** — Hermes Google Workspace tool stores a copy here. If the tool was installed but never configured, this may be empty or a stub.
- **`skills/productivity/<service>/credentials.json`** — Skill-bundled credential templates. Usually valid copies of the real OAuth secret.
- **`venv_*/` directories** — May contain `google-auth` library stubs, never actual secrets. Exclude from scan with `-not -path "*/venv/*"`.

## Pitfall: File Exists ≠ Valid Credential

Don't treat file existence as equivalent to "credential present." Always validate:
1. File size > 0
2. JSON parses correctly (for `.json` files)
3. Expected keys (`client_secret`, `refresh_token`, etc.) are present

A credential audit that lists a corrupt `credentials.json` as 🔴 without checking its content inflates the risk count and wastes rotation effort. Classify as 🟡 "stale/misconfigured" until manually verified.
